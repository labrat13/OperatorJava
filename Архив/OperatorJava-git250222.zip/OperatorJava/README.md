# OperatorJava
Java-1.8 version of myOperator for Linux 

Currently project under construction: porting from Windows C# to Linux Java.

